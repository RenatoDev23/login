package br.apptLogin.apptLogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApptLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApptLoginApplication.class, args);
	}

}
