package br.apptLogin.apptLogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApptLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
